# -*- coding: utf-8 -*-

import re
import nwae.utils.Log as log
from inspect import currentframe, getframeinfo


class PosTagging:

    def __init__(self):
        return

    
if __name__ == '__main__':
    exit(0)