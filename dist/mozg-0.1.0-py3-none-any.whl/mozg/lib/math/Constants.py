

class Constants:

    SMALL_VALUE = 0.0000001