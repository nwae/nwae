# -*- coding: utf-8 -*-

import re
import nwae.lib.lang.characters.LangCharacters as lc
import nwae.lib.lang.LangFeatures as lf
import nwae.lib.lang.nlp.WordList as wl
import nwae.lib.lang.nlp.SynonymList as slist
import nwae.lib.lang.stats.LangStats as ls
import nwae.utils.Log as log
from inspect import currentframe, getframeinfo
import hanziconv as hzc
import nwae.utils.Profiling as prf


class PosTagging:

    def __init__(self):
        return

    
if __name__ == '__main__':
    exit(0)