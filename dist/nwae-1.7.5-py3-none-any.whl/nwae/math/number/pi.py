# -*- coding: utf-8 -*-


class pi:

    def __init__(self):
        return


if __name__ == '__main__':
    exit(0)
